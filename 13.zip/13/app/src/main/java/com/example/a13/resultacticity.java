package com.example.votedemo

import android.os.Bundle
import android.widget.Button
import android.widget.RatingBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ResultActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.result)

        val intent = intent
        val voteResult = intent.getIntArrayExtra("VOTE_COUNT")
        val titleArray = intent.getStringArrayExtra("PICTURE_TITLE")

        if (voteResult == null || titleArray == null) {
            finish()
            return
        }

        val tvIDs = arrayOf(R.id.tv1, R.id.tv2, R.id.tv3, R.id.tv4, R.id.tv5, R.id.tv6, R.id.tv7, R.id.tv8, R.id.tv9)
        val rbarIDs = arrayOf(R.id.rbar1, R.id.rbar2, R.id.rbar3, R.id.rbar4, R.id.rbar5, R.id.rbar6, R.id.rbar7, R.id.rbar8, R.id.rbar9)

        val sum = voteResult.sum().toFloat()

        for (i in voteResult.indices) {
            val textView = findViewById<TextView>(tvIDs[i])
            val ratingBar = findViewById<RatingBar>(rbarIDs[i])

            if (i < titleArray.size) {
                textView.text = titleArray[i]
            } else {
                textView.text = "그림${i + 1}"
            }

            if (sum > 0) {
                val rating = (voteResult[i] / sum) * 5.0f
                ratingBar.rating = rating
            } else {
                ratingBar.rating = 0f
            }
        }

        val btnReturn = findViewById<Button>(R.id.btnReturn)
                btnReturn.setOnClickListener {
            finish()
        }
    }
}