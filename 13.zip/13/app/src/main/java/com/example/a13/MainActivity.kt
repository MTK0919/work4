package com.example.votedemo

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val voteCount = IntArray(9) { 0 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val imageIds = arrayOf(
            R.id.iv1, R.id.iv2, R.id.iv3, R.id.iv4, R.id.iv5,
            R.id.iv6, R.id.iv7, R.id.iv8, R.id.iv9
        )

        for (i in imageIds.indices) {
            val imageView = findViewById<ImageView>(imageIds[i])
            imageView.setOnClickListener {
                voteCount[i]++
                Toast.makeText(this, "투표했습니다!", Toast.LENGTH_SHORT).show()
            }
        }

        val btnResult = findViewById<Button>(R.id.btnResult)
        btnResult.setOnClickListener {
            val intent = Intent(this, ResultActivity::class.java)

            intent.putExtra("VOTE_COUNT", voteCount)
            intent.putExtra("PICTURE_TITLE", getPictureTitles())

            startActivity(intent)
        }
    }

    private fun getPictureTitles(): Array<String> {
        return arrayOf(
            "독서하는 소녀", "꽃장식 모자 소녀", "부채를 든 소녀",
            "이레느 레앵 단 베르양", "소파에 앉은 자매", "피아노 레슨",
            "미아노의 소녀들", "재봉선", "해변에서"
        )
    }
}