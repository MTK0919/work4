package com.example.selfproject4_4 

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.RadioGroup
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.a44.R

class MainActivity : AppCompatActivity() {


    private lateinit var switchStart: Switch
    private lateinit var tvQuestion: TextView
    private lateinit var radioGroup: RadioGroup
    private lateinit var imageViewAndroid: ImageView
    private lateinit var btnFinish: Button
    private lateinit var btnReset: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)


        switchStart = findViewById(R.id.switchStart)
        tvQuestion = findViewById(R.id.tvQuestion)
        radioGroup = findViewById(R.id.radioGroup)
        imageViewAndroid = findViewById(R.id.imageViewAndroid)
        btnFinish = findViewById(R.id.btnFinish)
        btnReset = findViewById(R.id.btnReset)


        setVisibleState(false)


        switchStart.setOnCheckedChangeListener { _, isChecked ->
            // isChecked가 true이면 화면 요소들을 보이게 하고, false이면 숨깁니다.
            setVisibleState(isChecked)
        }


        btnFinish.setOnClickListener {
            // 앱 종료
            finish()
        }

        btnReset.setOnClickListener {
            // Switch를 끄고 초기 상태로 되돌립니다.
            switchStart.isChecked = false
            radioGroup.clearCheck() // 라디오 버튼 선택 초기화
        }


        radioGroup.setOnCheckedChangeListener { _, checkedId ->
            // 예시: 선택된 라디오 버튼에 따라 다른 이미지로 변경 (실제 이미지 파일 필요)
            when (checkedId) {
                R.id.radioOreo -> {
                    // imageViewAndroid.setImageResource(R.drawable.android_oreo) // 오레오 이미지로 변경
                }
                R.id.radioPie -> {
                    imageViewAndroid.setImageResource(R.drawable.android_pie) // 파이 이미지 (제공된 이미지)
                }
                R.id.radioQ -> {
                    // imageViewAndroid.setImageResource(R.drawable.android_q) // Q 이미지로 변경
                }
            }
        }
    }


    private fun setVisibleState(isVisible: Boolean) {
        val visibility = if (isVisible) View.VISIBLE else View.INVISIBLE

        tvQuestion.visibility = visibility
        radioGroup.visibility = visibility
        imageViewAndroid.visibility = visibility
    }
}